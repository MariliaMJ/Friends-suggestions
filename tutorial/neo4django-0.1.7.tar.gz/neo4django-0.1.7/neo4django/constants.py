VERSION = '0.1.7'

INTERNAL_ATTR='_neo4django'

#gremlin-related constants
ERROR_ATTR=INTERNAL_ATTR + '_error'

#node-related constants
TYPE_ATTR=INTERNAL_ATTR + '_type'

#relationship-related constants
ORDER_ATTR=INTERNAL_ATTR + '_order'
